package sicob.controlador;

/** Lógica de la comunicación compleja: texto libre convertido a voz (RF5, RF6). */
public class TextoAVozControlador {

    public static final int MAX_CARACTERES = 250;

    public String[] velocidades() {
        return new String[]{"Lenta", "Normal", "Rápida"};
    }

    public String[] tonos() {
        return new String[]{"Grave", "Normal", "Agudo"};
    }

    /** @return mensaje de error, o null si el texto es válido. */
    public String validar(String texto) {
        if (texto == null || texto.trim().isEmpty()) {
            return "Escriba un mensaje antes de convertirlo a voz.";
        }
        if (texto.length() > MAX_CARACTERES) {
            return "El mensaje supera los " + MAX_CARACTERES + " caracteres.";
        }
        return null;
    }
}
