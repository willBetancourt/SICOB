package sicob.controlador;

import sicob.modelo.Audiencia;
import sicob.modelo.Categoria;
import sicob.modelo.Frase;
import sicob.modelo.RepositorioFrases;

import java.util.List;

/** Lógica del administrador: crear, editar y eliminar frases y botones (RF7). */
public class GestionFrasesControlador {

    private final RepositorioFrases repositorio;

    public GestionFrasesControlador(RepositorioFrases repositorio) {
        this.repositorio = repositorio;
    }

    public List<Frase> listar() {
        return repositorio.todas();
    }

    /** @throws IllegalArgumentException si los datos no son válidos. */
    public void agregar(Audiencia audiencia, Categoria categoria, String texto) {
        repositorio.agregar(new Frase(audiencia, categoria, validar(texto)));
    }

    /** @throws IllegalArgumentException si los datos no son válidos. */
    public void editar(Frase frase, Audiencia audiencia, Categoria categoria, String texto) {
        String limpio = validar(texto);
        frase.setAudiencia(audiencia);
        frase.setCategoria(categoria);
        frase.setTexto(limpio);
    }

    public void eliminar(Frase frase) {
        repositorio.eliminar(frase);
    }

    private String validar(String texto) {
        if (texto == null || texto.trim().isEmpty()) {
            throw new IllegalArgumentException("La frase no puede estar vacía.");
        }
        return texto.trim();
    }
}
