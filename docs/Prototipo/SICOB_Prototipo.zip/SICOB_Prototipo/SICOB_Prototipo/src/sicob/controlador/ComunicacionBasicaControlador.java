package sicob.controlador;

import sicob.modelo.Audiencia;
import sicob.modelo.Categoria;
import sicob.modelo.Frase;
import sicob.modelo.RepositorioFrases;

import java.util.List;

/** Lógica de la comunicación básica por botones (RF1, RF2, RF3, RF4). */
public class ComunicacionBasicaControlador {

    private final RepositorioFrases repositorio;

    public ComunicacionBasicaControlador(RepositorioFrases repositorio) {
        this.repositorio = repositorio;
    }

    /** Frases (botones) disponibles para un usuario y una categoría. */
    public List<Frase> frasesPara(Audiencia audiencia, Categoria categoria) {
        return repositorio.buscar(audiencia, categoria);
    }
}
