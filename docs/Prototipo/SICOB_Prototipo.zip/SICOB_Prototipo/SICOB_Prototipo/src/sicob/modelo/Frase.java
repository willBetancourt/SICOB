package sicob.modelo;

/** Frase predefinida que se representa como un botón en la interfaz. */
public class Frase {

    private Audiencia audiencia;
    private Categoria categoria;
    private String texto;

    public Frase(Audiencia audiencia, Categoria categoria, String texto) {
        this.audiencia = audiencia;
        this.categoria = categoria;
        this.texto = texto;
    }

    public Audiencia getAudiencia() { return audiencia; }
    public Categoria getCategoria() { return categoria; }
    public String getTexto() { return texto; }

    public void setAudiencia(Audiencia audiencia) { this.audiencia = audiencia; }
    public void setCategoria(Categoria categoria) { this.categoria = categoria; }
    public void setTexto(String texto) { this.texto = texto; }
}
