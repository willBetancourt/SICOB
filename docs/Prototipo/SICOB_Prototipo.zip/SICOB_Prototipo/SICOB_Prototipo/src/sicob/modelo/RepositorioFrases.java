package sicob.modelo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Almacén de frases en memoria con datos de ejemplo.
 * En el sistema real esto sería una base de datos; aquí es solo una maqueta.
 */
public class RepositorioFrases {

    private final List<Frase> frases = new ArrayList<>();

    public RepositorioFrases() {
        cargarDatosEjemplo();
    }

    public List<Frase> todas() {
        return Collections.unmodifiableList(frases);
    }

    public List<Frase> buscar(Audiencia audiencia, Categoria categoria) {
        List<Frase> resultado = new ArrayList<>();
        for (Frase f : frases) {
            if (f.getAudiencia() == audiencia && f.getCategoria() == categoria) {
                resultado.add(f);
            }
        }
        return resultado;
    }

    public void agregar(Frase frase) {
        frases.add(frase);
    }

    public void eliminar(Frase frase) {
        frases.remove(frase);
    }

    private void cargarDatosEjemplo() {
        Audiencia d = Audiencia.DISCAPACIDAD;
        agregar(new Frase(d, Categoria.SALUDOS, "Hola"));
        agregar(new Frase(d, Categoria.SALUDOS, "Buenos días"));
        agregar(new Frase(d, Categoria.SALUDOS, "Buenas tardes"));
        agregar(new Frase(d, Categoria.SALUDOS, "Buenas noches"));
        agregar(new Frase(d, Categoria.SALUDOS, "Hasta luego"));
        agregar(new Frase(d, Categoria.PRESENTACION, "Mucho gusto"));
        agregar(new Frase(d, Categoria.PRESENTACION, "Soy una persona sorda"));
        agregar(new Frase(d, Categoria.PRESENTACION, "Soy estudiante de la universidad"));
        agregar(new Frase(d, Categoria.PRESENTACION, "¿Cómo te llamas?"));
        agregar(new Frase(d, Categoria.LENGUAJE_BASICO, "Sí"));
        agregar(new Frase(d, Categoria.LENGUAJE_BASICO, "No"));
        agregar(new Frase(d, Categoria.LENGUAJE_BASICO, "Gracias"));
        agregar(new Frase(d, Categoria.LENGUAJE_BASICO, "Por favor"));
        agregar(new Frase(d, Categoria.LENGUAJE_BASICO, "Necesito ayuda"));
        agregar(new Frase(d, Categoria.LENGUAJE_BASICO, "No entiendo, repita por favor"));
        agregar(new Frase(d, Categoria.LENGUAJE_BASICO, "¿Dónde queda el baño?"));

        Audiencia o = Audiencia.OYENTE;
        agregar(new Frase(o, Categoria.SALUDOS, "Hola"));
        agregar(new Frase(o, Categoria.SALUDOS, "Buenos días"));
        agregar(new Frase(o, Categoria.SALUDOS, "Buenas tardes"));
        agregar(new Frase(o, Categoria.PRESENTACION, "Mucho gusto"));
        agregar(new Frase(o, Categoria.PRESENTACION, "¿Cómo te llamas?"));
        agregar(new Frase(o, Categoria.PRESENTACION, "Soy funcionario de la universidad"));
        agregar(new Frase(o, Categoria.LENGUAJE_BASICO, "Gracias"));
        agregar(new Frase(o, Categoria.LENGUAJE_BASICO, "Por favor"));
        agregar(new Frase(o, Categoria.LENGUAJE_BASICO, "¿Necesitas ayuda?"));
        agregar(new Frase(o, Categoria.LENGUAJE_BASICO, "Con gusto"));
        agregar(new Frase(o, Categoria.LENGUAJE_BASICO, "¿Puedes escribir tu mensaje?"));
    }
}
