package sicob.modelo;

/** A quién va dirigida una frase (qué usuario ve el botón). */
public enum Audiencia {
    DISCAPACIDAD("Persona con discapacidad"),
    OYENTE("Persona oyente");

    private final String etiqueta;

    Audiencia(String etiqueta) {
        this.etiqueta = etiqueta;
    }

    @Override
    public String toString() {
        return etiqueta;
    }
}
