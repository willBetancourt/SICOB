package sicob.modelo;

/** Categorías de frases básicas (saludos, presentaciones y lenguaje básico). */
public enum Categoria {
    SALUDOS("Saludos"),
    PRESENTACION("Presentación"),
    LENGUAJE_BASICO("Lenguaje básico");

    private final String etiqueta;

    Categoria(String etiqueta) {
        this.etiqueta = etiqueta;
    }

    @Override
    public String toString() {
        return etiqueta;
    }
}
