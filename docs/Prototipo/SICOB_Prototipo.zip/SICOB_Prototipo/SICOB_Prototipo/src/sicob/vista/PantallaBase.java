package sicob.vista;

import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;

/** Clase base de todas las pantallas: fondo, margen y ciclo de vida. */
public abstract class PantallaBase extends JPanel {

    protected final Navegacion navegacion;

    protected PantallaBase(Navegacion navegacion) {
        this.navegacion = navegacion;
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(16, 24, 16, 24));
    }

    /** Se invoca cada vez que la pantalla se vuelve visible (recargar datos, limpiar). */
    public void alMostrar() { }

    /** Se invoca cuando la pantalla deja de verse (detener animaciones). */
    public void alOcultar() { }
}
