package sicob.vista;

/** Contrato que usan las pantallas para pedir un cambio de pantalla. */
public interface Navegacion {
    void irA(Pantalla destino);
}
