package sicob.vista.pantallas;

import sicob.controlador.ComunicacionBasicaControlador;
import sicob.modelo.Audiencia;
import sicob.vista.Estilo;
import sicob.vista.Navegacion;
import sicob.vista.Pantalla;
import sicob.vista.PantallaBase;
import sicob.vista.componentes.PanelFrasesPorCategoria;
import sicob.vista.componentes.VideoPanel;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;

/** RF3 y RF4: la persona oyente elige una frase; el sistema muestra el video en Lengua de Señas. */
public class PantallaPersonaOyente extends PantallaBase {

    private final PanelFrasesPorCategoria frases;
    private final VideoPanel video = new VideoPanel();

    public PantallaPersonaOyente(Navegacion navegacion, ComunicacionBasicaControlador controlador) {
        super(navegacion);
        setLayout(new BorderLayout(16, 16));

        add(Estilo.encabezadoPantalla("Persona oyente: frases en Lengua de Señas",
                "Elija la frase que quiere decir; se mostrará el video en señas para la persona sorda."),
                BorderLayout.NORTH);

        frases = new PanelFrasesPorCategoria(controlador, Audiencia.OYENTE, Estilo.VERDE, video::reproducir);
        add(frases, BorderLayout.CENTER);

        JPanel dispositivo = new JPanel(new BorderLayout(0, 8));
        dispositivo.setBackground(java.awt.Color.WHITE);
        dispositivo.setBorder(Estilo.bordeDispositivo("Pantalla que ve la persona sorda"));
        dispositivo.setPreferredSize(new Dimension(380, 100));
        dispositivo.add(video, BorderLayout.CENTER);
        JButton repetir = Estilo.boton("Repetir video", Estilo.VERDE);
        repetir.addActionListener(e -> video.repetir());
        dispositivo.add(repetir, BorderLayout.SOUTH);
        add(dispositivo, BorderLayout.EAST);

        JPanel sur = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        sur.setOpaque(false);
        JButton volver = Estilo.boton("Volver al menú de usuario", Estilo.GRIS);
        volver.addActionListener(e -> navegacion.irA(Pantalla.MENU_USUARIO));
        sur.add(volver);
        add(sur, BorderLayout.SOUTH);
    }

    @Override
    public void alMostrar() {
        frases.recargar();
        video.reiniciar();
    }

    @Override
    public void alOcultar() {
        video.detener();
    }
}
