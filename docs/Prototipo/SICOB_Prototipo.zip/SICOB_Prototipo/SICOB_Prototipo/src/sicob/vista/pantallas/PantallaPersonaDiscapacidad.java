package sicob.vista.pantallas;

import sicob.controlador.ComunicacionBasicaControlador;
import sicob.modelo.Audiencia;
import sicob.vista.Estilo;
import sicob.vista.Navegacion;
import sicob.vista.Pantalla;
import sicob.vista.PantallaBase;
import sicob.vista.componentes.PanelFrasesPorCategoria;
import sicob.vista.componentes.PanelSalidaAudio;

import javax.swing.JButton;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.FlowLayout;

/** RF1 y RF2: la persona con discapacidad elige un mensaje básico; el oyente lo ve y lo escucha. */
public class PantallaPersonaDiscapacidad extends PantallaBase {

    private final PanelFrasesPorCategoria frases;
    private final PanelSalidaAudio salida =
            new PanelSalidaAudio("Pantalla que ve la persona oyente", Estilo.AZUL, 320);

    public PantallaPersonaDiscapacidad(Navegacion navegacion, ComunicacionBasicaControlador controlador) {
        super(navegacion);
        setLayout(new BorderLayout(16, 16));

        add(Estilo.encabezadoPantalla("Persona con discapacidad: mensajes básicos",
                "Elija una categoría y toque el botón del mensaje que desea comunicar."), BorderLayout.NORTH);

        frases = new PanelFrasesPorCategoria(controlador, Audiencia.DISCAPACIDAD, Estilo.AZUL,
                texto -> salida.reproducir(texto, "Reproduciendo audio...", "Audio reproducido"));
        add(frases, BorderLayout.CENTER);
        add(salida, BorderLayout.EAST);

        JPanel sur = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        sur.setOpaque(false);
        JButton complejo = Estilo.boton("Necesito escribir otro mensaje (texto libre)", Estilo.NARANJA);
        complejo.addActionListener(e -> navegacion.irA(Pantalla.COMUNICACION_COMPLEJA));
        JButton volver = Estilo.boton("Volver al menú de usuario", Estilo.GRIS);
        volver.addActionListener(e -> navegacion.irA(Pantalla.MENU_USUARIO));
        sur.add(volver);
        sur.add(complejo);
        add(sur, BorderLayout.SOUTH);
    }

    @Override
    public void alMostrar() {
        frases.recargar();
        salida.limpiar();
    }

    @Override
    public void alOcultar() {
        salida.detener();
    }
}
