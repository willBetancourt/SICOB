package sicob.vista.componentes;

import sicob.vista.Estilo;

import javax.swing.BoxLayout;
import javax.swing.Box;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.SwingConstants;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;

/**
 * Simula la pantalla del dispositivo de la persona oyente: muestra el mensaje
 * y una barra que representa el audio reproduciéndose.
 * Se reutiliza en la comunicación básica y en la comunicación compleja.
 */
public class PanelSalidaAudio extends JPanel {

    private static final int ANCHO_TEXTO = 240;

    private final JLabel lblMensaje = new JLabel("", SwingConstants.CENTER);
    private final JLabel lblEstado = new JLabel(" ", SwingConstants.CENTER);
    private final JProgressBar barra = new JProgressBar(0, 100);
    private final SimuladorProgreso simulador = new SimuladorProgreso(barra, lblEstado);

    public PanelSalidaAudio(String titulo, Color colorBarra, int anchoPreferido) {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(Color.WHITE);
        setBorder(Estilo.bordeDispositivo(titulo));
        setPreferredSize(new Dimension(anchoPreferido, 100));

        lblMensaje.setFont(new Font("SansSerif", Font.BOLD, 20));
        lblMensaje.setAlignmentX(CENTER_ALIGNMENT);

        JLabel icono = new JLabel("[ ))) ]", SwingConstants.CENTER);
        icono.setFont(new Font("Monospaced", Font.BOLD, 28));
        icono.setForeground(Color.GRAY);
        icono.setAlignmentX(CENTER_ALIGNMENT);

        barra.setForeground(colorBarra);
        barra.setAlignmentX(CENTER_ALIGNMENT);
        barra.setMaximumSize(new Dimension(260, 18));

        lblEstado.setFont(Estilo.F_NORMAL);
        lblEstado.setAlignmentX(CENTER_ALIGNMENT);

        add(Box.createVerticalGlue());
        add(lblMensaje);
        add(Box.createVerticalStrut(20));
        add(icono);
        add(Box.createVerticalStrut(10));
        add(barra);
        add(Box.createVerticalStrut(8));
        add(lblEstado);
        add(Box.createVerticalGlue());

        limpiar();
    }

    public void reproducir(String mensaje, String textoEnCurso, String textoFinal) {
        lblMensaje.setText(Estilo.htmlCentrado(mensaje, ANCHO_TEXTO, false));
        simulador.iniciar(textoEnCurso, textoFinal);
    }

    public void limpiar() {
        simulador.limpiar();
        lblMensaje.setText(Estilo.htmlCentrado("(Aquí aparecerá el mensaje)", ANCHO_TEXTO, true));
    }

    public void detener() {
        simulador.detener();
    }
}
