package sicob.vista.componentes;

import sicob.controlador.ComunicacionBasicaControlador;
import sicob.modelo.Audiencia;
import sicob.modelo.Categoria;
import sicob.modelo.Frase;
import sicob.vista.Estilo;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.border.EmptyBorder;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.util.List;
import java.util.function.Consumer;

/** Pestañas por categoría con un botón por cada frase de una audiencia. */
public class PanelFrasesPorCategoria extends JTabbedPane {

    private final ComunicacionBasicaControlador controlador;
    private final Audiencia audiencia;
    private final Color colorBotones;
    private final Consumer<String> alPulsar;

    public PanelFrasesPorCategoria(ComunicacionBasicaControlador controlador, Audiencia audiencia,
                                   Color colorBotones, Consumer<String> alPulsar) {
        this.controlador = controlador;
        this.audiencia = audiencia;
        this.colorBotones = colorBotones;
        this.alPulsar = alPulsar;
        setFont(Estilo.F_SUB);
        recargar();
    }

    /** Vuelve a construir los botones con las frases actuales del repositorio. */
    public void recargar() {
        removeAll();
        for (Categoria categoria : Categoria.values()) {
            JPanel grid = new JPanel(new GridLayout(0, 2, 10, 10));
            grid.setBackground(Color.WHITE);

            List<Frase> frases = controlador.frasesPara(audiencia, categoria);
            if (frases.isEmpty()) {
                JLabel vacio = new JLabel("(No hay frases en esta categoría)");
                vacio.setFont(Estilo.F_NORMAL);
                grid.add(vacio);
            }
            for (Frase frase : frases) {
                JButton boton = Estilo.boton(frase.getTexto(), colorBotones);
                boton.addActionListener(e -> alPulsar.accept(frase.getTexto()));
                grid.add(boton);
            }

            JPanel envoltorio = new JPanel(new BorderLayout());
            envoltorio.setBackground(Color.WHITE);
            envoltorio.setBorder(new EmptyBorder(14, 14, 14, 14));
            envoltorio.add(grid, BorderLayout.NORTH);

            JScrollPane scroll = new JScrollPane(envoltorio);
            scroll.setBorder(null);
            addTab(categoria.toString(), scroll);
        }
    }
}
