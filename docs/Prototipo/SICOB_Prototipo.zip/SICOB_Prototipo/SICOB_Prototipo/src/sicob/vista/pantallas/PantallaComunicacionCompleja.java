package sicob.vista.pantallas;

import sicob.controlador.TextoAVozControlador;
import sicob.vista.Estilo;
import sicob.vista.Navegacion;
import sicob.vista.Pantalla;
import sicob.vista.PantallaBase;
import sicob.vista.componentes.PanelSalidaAudio;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;

/** RF5 y RF6: texto libre convertido a voz artificial. */
public class PantallaComunicacionCompleja extends PantallaBase {

    private final TextoAVozControlador controlador;
    private final JTextArea area = new JTextArea(8, 30);
    private final JLabel lblContador = new JLabel();
    private final JComboBox<String> cbVelocidad;
    private final JComboBox<String> cbTono;
    private final PanelSalidaAudio salida =
            new PanelSalidaAudio("Pantalla que ve la persona oyente", Estilo.NARANJA, 340);

    public PantallaComunicacionCompleja(Navegacion navegacion, TextoAVozControlador controlador) {
        super(navegacion);
        this.controlador = controlador;
        this.cbVelocidad = new JComboBox<>(controlador.velocidades());
        this.cbTono = new JComboBox<>(controlador.tonos());
        cbVelocidad.setSelectedItem("Normal");
        cbTono.setSelectedItem("Normal");
        setLayout(new BorderLayout(16, 16));

        add(Estilo.encabezadoPantalla("Comunicación compleja: texto libre a voz",
                "Escriba lo que quiere decir; el sistema lo leerá en voz alta para la persona oyente."),
                BorderLayout.NORTH);
        add(crearEditor(), BorderLayout.CENTER);
        add(salida, BorderLayout.EAST);

        JPanel sur = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        sur.setOpaque(false);
        JButton volver = Estilo.boton("Volver al menú de usuario", Estilo.GRIS);
        volver.addActionListener(e -> navegacion.irA(Pantalla.MENU_USUARIO));
        JButton basico = Estilo.boton("Ir a mensajes básicos", Estilo.AZUL);
        basico.addActionListener(e -> navegacion.irA(Pantalla.PERSONA_DISCAPACIDAD));
        sur.add(volver);
        sur.add(basico);
        add(sur, BorderLayout.SOUTH);

        actualizarContador();
    }

    private JPanel crearEditor() {
        JPanel panel = new JPanel(new BorderLayout(0, 10));
        panel.setOpaque(false);

        area.setFont(new Font("SansSerif", Font.PLAIN, 18));
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setBorder(new EmptyBorder(8, 8, 8, 8));
        area.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { actualizarContador(); }
            public void removeUpdate(DocumentEvent e) { actualizarContador(); }
            public void changedUpdate(DocumentEvent e) { actualizarContador(); }
        });
        JScrollPane scroll = new JScrollPane(area);
        scroll.setBorder(new TitledBorder("Su mensaje"));

        JPanel ajustes = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 4));
        ajustes.setOpaque(false);
        ajustes.setBorder(new TitledBorder("Ajustes de voz (ejemplo)"));
        ajustes.add(new JLabel("Idioma: Español (Colombia)"));
        ajustes.add(new JLabel("  Velocidad:"));
        ajustes.add(cbVelocidad);
        ajustes.add(new JLabel("Tono:"));
        ajustes.add(cbTono);

        JButton hablar = Estilo.boton("Convertir a voz y reproducir", Estilo.NARANJA);
        JButton borrar = Estilo.boton("Borrar", Estilo.GRIS);
        hablar.addActionListener(e -> convertirAVoz());
        borrar.addActionListener(e -> {
            area.setText("");
            salida.limpiar();
        });
        lblContador.setFont(Estilo.F_NORMAL);

        JPanel botones = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        botones.setOpaque(false);
        botones.add(hablar);
        botones.add(borrar);
        botones.add(lblContador);

        JPanel abajo = new JPanel(new GridLayout(2, 1, 0, 8));
        abajo.setOpaque(false);
        abajo.add(ajustes);
        abajo.add(botones);

        panel.add(scroll, BorderLayout.CENTER);
        panel.add(abajo, BorderLayout.SOUTH);
        return panel;
    }

    private void convertirAVoz() {
        String error = controlador.validar(area.getText());
        if (error != null) {
            JOptionPane.showMessageDialog(this, error, "Revise su mensaje", JOptionPane.WARNING_MESSAGE);
            return;
        }
        salida.reproducir(area.getText().trim(),
                "Voz artificial (" + cbVelocidad.getSelectedItem() + ", tono " + cbTono.getSelectedItem() + ")...",
                "Mensaje reproducido");
    }

    private void actualizarContador() {
        int n = area.getText().length();
        lblContador.setText(n + " / " + TextoAVozControlador.MAX_CARACTERES + " caracteres");
        lblContador.setForeground(n > TextoAVozControlador.MAX_CARACTERES ? Estilo.ROJO : Color.DARK_GRAY);
    }

    @Override
    public void alMostrar() {
        salida.limpiar();
    }

    @Override
    public void alOcultar() {
        salida.detener();
    }
}
