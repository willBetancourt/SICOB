package sicob.vista.componentes;

import javax.swing.JPanel;
import javax.swing.Timer;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;

/** Reproductor de "video" simulado: un muñeco que mueve los brazos mientras "habla" en señas. */
public class VideoPanel extends JPanel {

    private String frase = null;
    private int progreso = 0;
    private double fase = 0;
    private boolean reproduciendo = false;
    private Timer timer;

    public VideoPanel() {
        setBackground(new Color(0x2B2B2B));
    }

    public void reproducir(String texto) {
        detener();
        frase = texto;
        progreso = 0;
        reproduciendo = true;
        timer = new Timer(40, e -> {
            progreso += 2;
            fase += 0.45;
            if (progreso >= 100) {
                progreso = 100;
                reproduciendo = false;
                timer.stop();
            }
            repaint();
        });
        timer.start();
    }

    public void repetir() {
        if (frase != null) {
            reproducir(frase);
        }
    }

    public void reiniciar() {
        detener();
        frase = null;
        progreso = 0;
        repaint();
    }

    public void detener() {
        if (timer != null) {
            timer.stop();
        }
        reproduciendo = false;
    }

    @Override
    protected void paintComponent(Graphics g0) {
        super.paintComponent(g0);
        Graphics2D g = (Graphics2D) g0;
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        int w = getWidth();
        int h = getHeight();

        g.setColor(new Color(0xBBBBBB));
        g.setFont(new Font("SansSerif", Font.BOLD, 12));
        g.drawString("VIDEO EN LENGUA DE SEÑAS (LSC) - simulado", 12, 20);

        if (frase == null) {
            g.setFont(new Font("SansSerif", Font.PLAIN, 16));
            g.setColor(Color.LIGHT_GRAY);
            String m = "Seleccione una frase";
            g.drawString(m, (w - g.getFontMetrics().stringWidth(m)) / 2, h / 2);
            return;
        }

        int cx = w / 2;
        int cy = h / 2 - 20;
        Color piel = new Color(0xE0B88A);

        g.setColor(piel);
        g.fillOval(cx - 28, cy - 90, 56, 56);                       // cabeza
        g.setStroke(new BasicStroke(10, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g.setColor(new Color(0x4A90D9));
        g.drawLine(cx, cy - 34, cx, cy + 60);                       // torso

        double a = reproduciendo ? Math.sin(fase) * 0.6 : 0;
        double b = reproduciendo ? Math.cos(fase) * 0.6 : 0;
        int izqX = (int) (cx - 70 - 20 * Math.sin(fase));
        int izqY = (int) (cy - 10 - 55 * (0.5 + a));
        int derX = (int) (cx + 70 + 20 * Math.cos(fase));
        int derY = (int) (cy - 10 - 55 * (0.5 + b));
        g.drawLine(cx, cy - 20, izqX, izqY);                        // brazo izquierdo
        g.drawLine(cx, cy - 20, derX, derY);                        // brazo derecho
        g.setColor(piel);
        g.fillOval(izqX - 10, izqY - 10, 20, 20);
        g.fillOval(derX - 10, derY - 10, 20, 20);

        g.setFont(new Font("SansSerif", Font.BOLD, 18));
        g.setColor(Color.WHITE);
        int tw = g.getFontMetrics().stringWidth(frase);
        g.drawString(frase, Math.max(8, (w - tw) / 2), h - 44);     // subtítulo

        g.setStroke(new BasicStroke(1));
        g.setColor(new Color(0x555555));
        g.fillRect(12, h - 24, w - 24, 8);
        g.setColor(reproduciendo ? new Color(0x4CAF50) : new Color(0x888888));
        g.fillRect(12, h - 24, (int) ((w - 24) * progreso / 100.0), 8);
        g.setColor(Color.WHITE);
        g.setFont(new Font("SansSerif", Font.PLAIN, 11));
        g.drawString(reproduciendo ? "Reproduciendo..." : "Fin del video", 12, h - 6);
    }
}
