package sicob.vista.pantallas;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import sicob.vista.Estilo;
import sicob.vista.Navegacion;
import sicob.vista.Pantalla;
import sicob.vista.PantallaBase;

/** Primer menú: el usuario indica si ingresa como Usuario o como Administrador. */
public class PantallaMenuPrincipal extends PantallaBase {

    public PantallaMenuPrincipal(Navegacion navegacion) {
        super(navegacion);
        setLayout(new BorderLayout(0, 24));

        JLabel titulo = new JLabel("Sistema de Comunicación Bidireccional", SwingConstants.CENTER);
        titulo.setFont(Estilo.F_TITULO);
        titulo.setForeground(Estilo.AZUL);
        JLabel sub = new JLabel("¿Cómo desea ingresar?", SwingConstants.CENTER);
        sub.setFont(Estilo.F_SUB);
        JPanel norte = new JPanel(new GridLayout(2, 1, 0, 8));
        norte.setOpaque(false);
        norte.add(titulo);
        norte.add(sub);

        JPanel tarjetas = new JPanel(new GridLayout(1, 2, 30, 0));
        tarjetas.setOpaque(false);
        tarjetas.setBorder(BorderFactory.createEmptyBorder(20, 80, 60, 80));
        tarjetas.add(Estilo.tarjeta("Usuario",
                "Comunicarse entre la comunidad sorda y la comunidad oyente", "",
                Estilo.AZUL, () -> navegacion.irA(Pantalla.MENU_USUARIO)));
        tarjetas.add(Estilo.tarjeta("Administrador",
                "Gestionar las frases y los botones del sistema", "",
                Estilo.MORADO, () -> navegacion.irA(Pantalla.ADMINISTRADOR)));

        add(norte, BorderLayout.NORTH);
        add(tarjetas, BorderLayout.CENTER);
    }
}
