package sicob.vista.pantallas;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import sicob.controlador.GestionFrasesControlador;
import sicob.modelo.Audiencia;
import sicob.modelo.Categoria;
import sicob.modelo.Frase;
import sicob.vista.Estilo;
import sicob.vista.Navegacion;
import sicob.vista.Pantalla;
import sicob.vista.PantallaBase;

/** RF7: el administrador crea, edita y elimina las frases y botones del sistema. */
public class PantallaAdministrador extends PantallaBase {

    /** Datos capturados en el formulario de agregar/editar. */
    private static class DatosFormulario {
        final Audiencia audiencia;
        final Categoria categoria;
        final String texto;

        DatosFormulario(Audiencia audiencia, Categoria categoria, String texto) {
            this.audiencia = audiencia;
            this.categoria = categoria;
            this.texto = texto;
        }
    }

    private final GestionFrasesControlador controlador;
    private final DefaultTableModel modelo = new DefaultTableModel(
            new String[]{"Dirigido a", "Categoría", "Frase del botón"}, 0) {
        @Override
        public boolean isCellEditable(int fila, int columna) {
            return false;
        }
    };
    private final JTable tabla = new JTable(modelo);
    private List<Frase> filas = new ArrayList<>();

    public PantallaAdministrador(Navegacion navegacion, GestionFrasesControlador controlador) {
        super(navegacion);
        this.controlador = controlador;
        setLayout(new BorderLayout(16, 16));

        add(Estilo.encabezadoPantalla("Administrador: gestión de frases y botones",
                "Los cambios se publican de inmediato para la persona con discapacidad y la persona oyente."),
                BorderLayout.NORTH);

        tabla.setFont(Estilo.F_NORMAL);
        tabla.setRowHeight(28);
        tabla.getTableHeader().setFont(Estilo.F_SUB);
        tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabla.setAutoCreateRowSorter(true);
        add(new JScrollPane(tabla), BorderLayout.CENTER);
        add(crearBotonesLaterales(), BorderLayout.EAST);

        JPanel sur = new JPanel(new BorderLayout());
        sur.setOpaque(false);
        JButton volver = Estilo.boton("Volver al inicio", Estilo.GRIS);
        volver.addActionListener(e -> navegacion.irA(Pantalla.MENU_PRINCIPAL));
        JPanel izq = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        izq.setOpaque(false);
        izq.add(volver);

    }

    private JPanel crearBotonesLaterales() {
        JButton nuevo = Estilo.boton("Agregar frase", Estilo.VERDE);
        JButton editar = Estilo.boton("Editar seleccionada", Estilo.AZUL);
        JButton eliminar = Estilo.boton("Eliminar seleccionada", Estilo.ROJO);
        nuevo.addActionListener(e -> agregar());
        editar.addActionListener(e -> editar());
        eliminar.addActionListener(e -> eliminar());

        JPanel lado = new JPanel(new GridLayout(0, 1, 0, 10));
        lado.setOpaque(false);
        lado.add(nuevo);
        lado.add(editar);
        lado.add(eliminar);

        JPanel envoltorio = new JPanel(new BorderLayout());
        envoltorio.setOpaque(false);
        envoltorio.add(lado, BorderLayout.NORTH);
        return envoltorio;
    }

    private void agregar() {
        DatosFormulario d = pedirDatos(null);
        if (d == null) return;
        try {
            controlador.agregar(d.audiencia, d.categoria, d.texto);
            confirmarCambio();
        } catch (IllegalArgumentException ex) {
            avisar(ex.getMessage());
        }
    }

    private void editar() {
        Frase frase = seleccionada();
        if (frase == null) return;
        DatosFormulario d = pedirDatos(frase);
        if (d == null) return;
        try {
            controlador.editar(frase, d.audiencia, d.categoria, d.texto);
            confirmarCambio();
        } catch (IllegalArgumentException ex) {
            avisar(ex.getMessage());
        }
    }

    private void eliminar() {
        Frase frase = seleccionada();
        if (frase == null) return;
        int r = JOptionPane.showConfirmDialog(this,
                "¿Eliminar el botón \"" + frase.getTexto() + "\"?", "Confirmar",
                JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (r == JOptionPane.YES_OPTION) {
            controlador.eliminar(frase);
            confirmarCambio();
        }
    }

    private Frase seleccionada() {
        int vista = tabla.getSelectedRow();
        if (vista < 0) {
            JOptionPane.showMessageDialog(this, "Seleccione primero una fila de la tabla.",
                    "Sin selección", JOptionPane.INFORMATION_MESSAGE);
            return null;
        }
        return filas.get(tabla.convertRowIndexToModel(vista));
    }

    private DatosFormulario pedirDatos(Frase base) {
        JComboBox<Audiencia> cbAudiencia = new JComboBox<>(Audiencia.values());
        JComboBox<Categoria> cbCategoria = new JComboBox<>(Categoria.values());
        JTextField txtFrase = new JTextField(22);
        if (base != null) {
            cbAudiencia.setSelectedItem(base.getAudiencia());
            cbCategoria.setSelectedItem(base.getCategoria());
            txtFrase.setText(base.getTexto());
        }
        JPanel form = new JPanel(new GridLayout(0, 2, 8, 8));
        form.setBorder(new EmptyBorder(4, 4, 4, 4));
        form.add(new JLabel("Dirigido a:"));
        form.add(cbAudiencia);
        form.add(new JLabel("Categoría:"));
        form.add(cbCategoria);
        form.add(new JLabel("Frase del botón:"));
        form.add(txtFrase);

        int r = JOptionPane.showConfirmDialog(this, form,
                base == null ? "Agregar frase" : "Editar frase",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (r != JOptionPane.OK_OPTION) return null;
        return new DatosFormulario((Audiencia) cbAudiencia.getSelectedItem(),
                (Categoria) cbCategoria.getSelectedItem(), txtFrase.getText());
    }

    private void confirmarCambio() {
        recargarTabla();
        JOptionPane.showMessageDialog(this, "Cambios guardados y publicados.",
                "Listo", JOptionPane.INFORMATION_MESSAGE);
    }

    private void avisar(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Dato inválido", JOptionPane.WARNING_MESSAGE);
    }

    private void recargarTabla() {
        modelo.setRowCount(0);
        filas = new ArrayList<>(controlador.listar());
        for (Frase f : filas) {
            modelo.addRow(new Object[]{f.getAudiencia(), f.getCategoria(), f.getTexto()});
        }
    }

    @Override
    public void alMostrar() {
        recargarTabla();
    }
}
