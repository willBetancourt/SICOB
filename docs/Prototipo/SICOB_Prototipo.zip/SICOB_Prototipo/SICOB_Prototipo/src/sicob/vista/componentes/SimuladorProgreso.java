package sicob.vista.componentes;

import javax.swing.JLabel;
import javax.swing.JProgressBar;
import javax.swing.Timer;

/** Anima una barra de progreso para simular que un audio se está reproduciendo. */
public class SimuladorProgreso {

    private final JProgressBar barra;
    private final JLabel estado;
    private Timer timer;

    public SimuladorProgreso(JProgressBar barra, JLabel estado) {
        this.barra = barra;
        this.estado = estado;
    }

    public void iniciar(String textoEnCurso, String textoFinal) {
        detener();
        barra.setValue(0);
        estado.setText(textoEnCurso);
        final int[] valor = {0};
        timer = new Timer(40, null);
        timer.addActionListener(e -> {
            valor[0] += 2;
            barra.setValue(valor[0]);
            if (valor[0] >= 100) {
                timer.stop();
                estado.setText(textoFinal);
            }
        });
        timer.start();
    }

    public void detener() {
        if (timer != null) {
            timer.stop();
        }
    }

    public void limpiar() {
        detener();
        barra.setValue(0);
        estado.setText(" ");
    }
}
