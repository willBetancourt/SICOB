package sicob.vista;

/** Pantallas del prototipo y su "ruta de migas" que se muestra en el encabezado. */
public enum Pantalla {
    MENU_PRINCIPAL("Inicio"),
    MENU_USUARIO("Inicio  >  Usuario"),
    PERSONA_DISCAPACIDAD("Inicio  >  Usuario  >  Persona con discapacidad"),
    PERSONA_OYENTE("Inicio  >  Usuario  >  Persona oyente"),
    COMUNICACION_COMPLEJA("Inicio  >  Usuario  >  Comunicación compleja"),
    ADMINISTRADOR("Inicio  >  Administrador  >  Gestión de frases");

    private final String ruta;

    Pantalla(String ruta) {
        this.ruta = ruta;
    }

    public String getRuta() {
        return ruta;
    }
}
