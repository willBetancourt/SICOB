package sicob.vista.pantallas;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JPanel;
import sicob.vista.Estilo;
import sicob.vista.Navegacion;
import sicob.vista.Pantalla;
import sicob.vista.PantallaBase;

/** Menú del usuario: persona con discapacidad, persona oyente o comunicación compleja. */
public class PantallaMenuUsuario extends PantallaBase {

    public PantallaMenuUsuario(Navegacion navegacion) {
        super(navegacion);
        setLayout(new BorderLayout(0, 24));

        add(Estilo.encabezadoPantalla("Menú de usuario", "¿Qué desea hacer?"), BorderLayout.NORTH);

        JPanel tarjetas = new JPanel(new GridLayout(1, 3, 20, 0));
        tarjetas.setOpaque(false);
        tarjetas.setBorder(BorderFactory.createEmptyBorder(20, 20, 40, 20));
        tarjetas.add(Estilo.tarjeta("Persona con discapacidad",
                "Enviar un mensaje básico con botones", "",
                Estilo.AZUL, () -> navegacion.irA(Pantalla.PERSONA_DISCAPACIDAD)));
        tarjetas.add(Estilo.tarjeta("Persona oyente",
                "Elegir una frase y ver el video en Lengua de Señas", "",
                Estilo.VERDE, () -> navegacion.irA(Pantalla.PERSONA_OYENTE)));
        tarjetas.add(Estilo.tarjeta("Comunicación compleja",
                "Escribir un mensaje libre y convertirlo a voz", "",
                Estilo.NARANJA, () -> navegacion.irA(Pantalla.COMUNICACION_COMPLEJA)));
        add(tarjetas, BorderLayout.CENTER);

        JPanel sur = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        sur.setOpaque(false);
        JButton volver = Estilo.boton("Volver", Estilo.GRIS);
        volver.addActionListener(e -> navegacion.irA(Pantalla.MENU_PRINCIPAL));
        sur.add(volver);
        add(sur, BorderLayout.SOUTH);
    }
}
