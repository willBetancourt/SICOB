package sicob.vista;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.util.EnumMap;
import java.util.Map;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import sicob.controlador.ComunicacionBasicaControlador;
import sicob.controlador.GestionFrasesControlador;
import sicob.controlador.TextoAVozControlador;
import sicob.modelo.RepositorioFrases;
import sicob.vista.pantallas.PantallaAdministrador;
import sicob.vista.pantallas.PantallaComunicacionCompleja;
import sicob.vista.pantallas.PantallaMenuPrincipal;
import sicob.vista.pantallas.PantallaMenuUsuario;
import sicob.vista.pantallas.PantallaPersonaDiscapacidad;
import sicob.vista.pantallas.PantallaPersonaOyente;

/** Ventana única del prototipo: arma las capas y administra la navegación entre pantallas. */
public class VentanaPrincipal extends JFrame implements Navegacion {

    private final CardLayout cartas = new CardLayout();
    private final JPanel contenedor = new JPanel(cartas);
    private final JLabel lblRuta = new JLabel();
    private final Map<Pantalla, PantallaBase> pantallas = new EnumMap<>(Pantalla.class);
    private Pantalla actual;

    public VentanaPrincipal() {
        super("SICOB - Prototipo (maqueta)");

        // Modelo
        RepositorioFrases repositorio = new RepositorioFrases();
        // Controladores
        ComunicacionBasicaControlador basica = new ComunicacionBasicaControlador(repositorio);
        TextoAVozControlador textoAVoz = new TextoAVozControlador();
        GestionFrasesControlador gestion = new GestionFrasesControlador(repositorio);

        // Vistas
        registrar(Pantalla.MENU_PRINCIPAL, new PantallaMenuPrincipal(this));
        registrar(Pantalla.MENU_USUARIO, new PantallaMenuUsuario(this));
        registrar(Pantalla.PERSONA_DISCAPACIDAD, new PantallaPersonaDiscapacidad(this, basica));
        registrar(Pantalla.PERSONA_OYENTE, new PantallaPersonaOyente(this, basica));
        registrar(Pantalla.COMUNICACION_COMPLEJA, new PantallaComunicacionCompleja(this, textoAVoz));
        registrar(Pantalla.ADMINISTRADOR, new PantallaAdministrador(this, gestion));

        setLayout(new BorderLayout());
        add(crearEncabezado(), BorderLayout.NORTH);
        add(contenedor, BorderLayout.CENTER);
        

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1000, 680);
        setMinimumSize(new Dimension(900, 620));
        setLocationRelativeTo(null);

        irA(Pantalla.MENU_PRINCIPAL);
    }

    private void registrar(Pantalla id, PantallaBase pantalla) {
        pantallas.put(id, pantalla);
        contenedor.add(pantalla, id.name());
    }

    @Override
    public void irA(Pantalla destino) {
        if (actual != null) {
            pantallas.get(actual).alOcultar();
        }
        actual = destino;
        lblRuta.setText(destino.getRuta());
        pantallas.get(destino).alMostrar();
        cartas.show(contenedor, destino.name());
    }

    private JPanel crearEncabezado() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(Estilo.AZUL);
        p.setBorder(new EmptyBorder(10, 16, 10, 16));

        JLabel logo = new JLabel("SICOB");
        logo.setFont(new Font("SansSerif", Font.BOLD, 26));
        logo.setForeground(Color.WHITE);
        lblRuta.setFont(Estilo.F_NORMAL);
        lblRuta.setForeground(new Color(0xBFD0E6));
        lblRuta.setBorder(new EmptyBorder(0, 16, 0, 0));

        JPanel izq = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        izq.setOpaque(false);
        izq.add(logo);
        izq.add(lblRuta);

        JButton inicio = Estilo.boton("Inicio", Estilo.AZUL_MEDIO);
        inicio.addActionListener(e -> irA(Pantalla.MENU_PRINCIPAL));

        p.add(izq, BorderLayout.WEST);
        p.add(inicio, BorderLayout.EAST);
        return p;
    }

}
