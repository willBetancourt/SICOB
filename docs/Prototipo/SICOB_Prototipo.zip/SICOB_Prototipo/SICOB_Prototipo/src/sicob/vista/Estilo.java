package sicob.vista;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.GridLayout;

/** Colores, fuentes y fábricas de componentes compartidas por toda la interfaz. */
public final class Estilo {

    private Estilo() { }

    public static final Color AZUL = new Color(0x1F3A5F);
    public static final Color AZUL_MEDIO = new Color(0x3E5F8A);
    public static final Color VERDE = new Color(0x2E7D32);
    public static final Color NARANJA = new Color(0xD35400);
    public static final Color ROJO = new Color(0xC0392B);
    public static final Color MORADO = new Color(0x6C3483);
    public static final Color GRIS = new Color(0x7F8C8D);

    public static final Font F_TITULO = new Font("SansSerif", Font.BOLD, 22);
    public static final Font F_SUB = new Font("SansSerif", Font.BOLD, 15);
    public static final Font F_NORMAL = new Font("SansSerif", Font.PLAIN, 14);

    public static JButton boton(String texto, Color fondo) {
        JButton b = new JButton(texto);
        b.setFont(F_SUB);
        b.setBackground(fondo);
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        b.setOpaque(true);
        b.setBorder(new EmptyBorder(10, 18, 10, 18));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }

    /** Botón grande tipo "tarjeta" para los menús. */
    public static JButton tarjeta(String titulo, String descripcion, String referencia,
                                  Color color, Runnable accion) {
        String ref = referencia.isEmpty() ? "" : "<br><br><span style='font-size:11px'>" + referencia + "</span>";
        JButton b = new JButton("<html><div style='text-align:center;width:240px'>"
                + "<span style='font-size:18px'><b>" + titulo + "</b></span><br><br>"
                + descripcion + ref + "</div></html>");
        b.setFont(F_NORMAL);
        b.setBackground(color);
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        b.setOpaque(true);
        b.setBorder(new EmptyBorder(16, 16, 16, 16));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.addActionListener(e -> accion.run());
        return b;
    }

    /** Título + línea de ayuda, para la parte superior de cada pantalla. */
    public static JPanel encabezadoPantalla(String titulo, String ayuda) {
        JPanel p = new JPanel(new GridLayout(2, 1));
        p.setOpaque(false);
        JLabel t = new JLabel(titulo);
        t.setFont(F_TITULO);
        t.setForeground(AZUL);
        JLabel a = new JLabel(ayuda);
        a.setFont(F_NORMAL);
        p.add(t);
        p.add(a);
        return p;
    }

    /** Borde que simula el marco de la pantalla de un dispositivo. */
    public static Border bordeDispositivo(String titulo) {
        return new CompoundBorder(
                new TitledBorder(new LineBorder(Color.GRAY, 2, true), titulo,
                        TitledBorder.CENTER, TitledBorder.TOP, F_SUB),
                BorderFactory.createEmptyBorder(10, 14, 14, 14));
    }

    /** Convierte texto plano en HTML centrado y con ancho fijo (con saltos de línea). */
    public static String htmlCentrado(String texto, int ancho, boolean gris) {
        String seguro = texto.replace("&", "&amp;").replace("<", "&lt;")
                .replace(">", "&gt;").replace("\n", "<br>");
        return "<html><div style='text-align:center;width:" + ancho + "px"
                + (gris ? ";color:gray" : "") + "'>" + seguro + "</div></html>";
    }
}
