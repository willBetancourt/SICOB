package sicob;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import sicob.vista.VentanaPrincipal;

/** Punto de entrada del prototipo SICOB. */
public class Main {

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
        } catch (Exception ignorada) {
            // Se usa el aspecto por defecto.
        }
        SwingUtilities.invokeLater(() -> new VentanaPrincipal().setVisible(true));
    }
}
