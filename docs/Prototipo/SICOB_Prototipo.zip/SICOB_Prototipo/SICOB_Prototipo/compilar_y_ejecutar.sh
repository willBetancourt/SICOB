#!/bin/sh
# Compila y ejecuta el prototipo SICOB (requiere JDK 11 o superior)
cd "$(dirname "$0")"
mkdir -p out
find src -name "*.java" > fuentes.txt
javac -encoding UTF-8 -d out @fuentes.txt && java -cp out sicob.Main
