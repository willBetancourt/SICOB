@echo off
cd /d "%~dp0"
if not exist out mkdir out
dir /s /b src\*.java > fuentes.txt
javac -encoding UTF-8 -d out @fuentes.txt
if %errorlevel%==0 java -cp out sicob.Main
pause
