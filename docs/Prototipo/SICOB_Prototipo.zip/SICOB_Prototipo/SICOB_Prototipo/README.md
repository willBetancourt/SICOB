# SICOB - Prototipo (maqueta de baja fidelidad)

Prototipo navegable del Sistema de Comunicación Bidireccional (SICOB), hecho en Java Swing
(sin librerías externas) para mostrarle al cliente cómo podría verse la aplicación.
El audio, los videos y los datos son simulados.

## Cómo ejecutarlo (requiere JDK 11 o superior)

- Windows: doble clic en `compilar_y_ejecutar.bat`
- Linux / macOS: `./compilar_y_ejecutar.sh`
- A mano:
  ```
  find src -name "*.java" > fuentes.txt      (en Windows: dir /s /b src\*.java > fuentes.txt)
  javac -encoding UTF-8 -d out @fuentes.txt
  java -cp out sicob.Main
  ```
- También se puede abrir la carpeta `src` como proyecto en NetBeans, IntelliJ o Eclipse (clase principal: `sicob.Main`).

## Flujo de navegación

```
Menú principal
 ├── Usuario
 │    ├── Persona con discapacidad   (RF1, RF2)
 │    ├── Persona oyente             (RF3, RF4)
 │    └── Comunicación compleja      (RF5, RF6)
 └── Administrador                   (RF7)
```

## Arquitectura (capas, tipo MVC)

| Paquete | Responsabilidad |
|---|---|
| `sicob.modelo` | Datos del dominio: `Frase`, `Categoria`, `Audiencia` y `RepositorioFrases` (almacén en memoria). |
| `sicob.controlador` | Reglas de la aplicación, sin código de interfaz: `ComunicacionBasicaControlador` (RF1-RF4), `TextoAVozControlador` (RF5-RF6, validación de 250 caracteres), `GestionFrasesControlador` (RF7, validación y CRUD). |
| `sicob.vista` | `VentanaPrincipal` (navegación), `Estilo` (colores y fuentes), `Pantalla`, `Navegacion`, `PantallaBase`. |
| `sicob.vista.pantallas` | Una clase por pantalla: menú principal, menú usuario, persona con discapacidad, persona oyente, comunicación compleja y administrador. |
| `sicob.vista.componentes` | Componentes reutilizables: `PanelFrasesPorCategoria`, `PanelSalidaAudio`, `VideoPanel`, `SimuladorProgreso`. |

Las vistas llaman a los controladores, los controladores usan el modelo, y el modelo no conoce a nadie.

## Qué NO incluye (queda para la versión real)

RF8 (carga de videos en LSC), RF9 (motor de voz real), autenticación del administrador y persistencia en base de datos.
